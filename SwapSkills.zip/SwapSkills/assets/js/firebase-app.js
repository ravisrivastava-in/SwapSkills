/**
 * ============================================================
 * SwapSkills — firebase-app.js
 * ============================================================
 * Consolidated Firebase script (ES-module) that every page
 * can import.  It re-exports every function the UI layer needs
 * so that HTML pages only have ONE import line.
 *
 * Usage in any page:
 *   <script type="module" src="assets/js/firebase-app.js"></script>
 *   — then access  window.SS.*  from inline <script type="module"> blocks
 * ============================================================
 */

// ────────────────────────────────────────────────────────
// 1.  Firebase SDK imports  (CDN, v12.10.0)
// ────────────────────────────────────────────────────────
import { initializeApp }
  from "https://www.gstatic.com/firebasejs/12.10.0/firebase-app.js";

import {
  getAuth, onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut, updateProfile
} from "https://www.gstatic.com/firebasejs/12.10.0/firebase-auth.js";

import {
  getFirestore, doc, setDoc, getDoc, getDocs,
  updateDoc, deleteDoc, collection, query, where,
  onSnapshot, arrayUnion, arrayRemove,
  serverTimestamp, orderBy, limit, addDoc
} from "https://www.gstatic.com/firebasejs/12.10.0/firebase-firestore.js";

import {
  getDatabase, ref, push, onChildAdded,
  set as rtdbSet, onValue, off,
  serverTimestamp as rtdbTimestamp
} from "https://www.gstatic.com/firebasejs/12.10.0/firebase-database.js";


// ────────────────────────────────────────────────────────
// 2.  Firebase configuration & initialisation
// ────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey:            "AIzaSyCbZjbvUBDZAcifp_vQN3WQzn_1Uail01c",
  authDomain:        "swapskills-in.firebaseapp.com",
  projectId:         "swapskills-in",
  storageBucket:     "swapskills-in.firebasestorage.app",
  messagingSenderId: "792354505254",
  appId:             "1:792354505254:web:8329d79feb97e7f4af1ce7",
  measurementId:     "G-9LFR0ZQY4G",
  databaseURL:       "https://swapskills-in-default-rtdb.firebaseio.com"
};

const app  = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db   = getFirestore(app);
const rtdb = getDatabase(app);


// ────────────────────────────────────────────────────────
// 3.  Skill categories (shared constant)
// ────────────────────────────────────────────────────────
const SKILL_CATEGORIES = [
  "Technology", "Design", "Language", "Music",
  "Business", "Science", "Art", "Fitness",
  "Cooking", "Photography", "Writing", "Other"
];


// ============================================================
// 4.  AUTH  functions
// ============================================================

/** Listen for auth-state changes */
function observeAuth(cb) {
  return onAuthStateChanged(auth, cb);
}

/** Register a new user + create Firestore profile */
async function signUp(email, password, displayName) {
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName });
    await setDoc(doc(db, "users", cred.user.uid), {
      uid: cred.user.uid,
      displayName,
      email,
      bio: "",
      skillsOffered: [],
      skillsWanted: [],
      averageRating: 0,
      createdAt: serverTimestamp()
    });
    return { success: true, user: cred.user };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Email/password login */
async function login(email, password) {
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, user: cred.user };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Logout */
async function logoutUser() {
  try { await signOut(auth); return { success: true }; }
  catch (e) { return { success: false, error: e.message }; }
}

/** Fetch Firestore user profile */
async function getUserProfile(uid) {
  try {
    const snap = await getDoc(doc(db, "users", uid));
    return snap.exists() ? snap.data() : null;
  } catch (e) { console.error("getUserProfile:", e); return null; }
}

/** Update (merge) Firestore user profile */
async function updateUserProfile(uid, data) {
  try {
    await setDoc(doc(db, "users", uid), data, { merge: true });
    return { success: true };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Get current Firebase auth user */
function getCurrentUser() { return auth.currentUser; }


// ============================================================
// 5.  SKILL MANAGEMENT  functions
// ============================================================

/**
 * Add a skill to 'skillsOffered' or 'skillsWanted'
 * @param {string} uid       User ID
 * @param {object} skill     { name, category, level?, description? }
 * @param {string} type      'offered' | 'wanted'
 */
async function addSkill(uid, skill, type) {
  try {
    const field = type === "offered" ? "skillsOffered" : "skillsWanted";
    const obj = {
      id:          Date.now().toString(),
      name:        skill.name,
      category:    skill.category,
      level:       skill.level || "Beginner",
      description: skill.description || ""
    };
    await updateDoc(doc(db, "users", uid), { [field]: arrayUnion(obj) });
    return { success: true, skill: obj };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Remove a skill object from 'skillsOffered' or 'skillsWanted' */
async function removeSkill(uid, skillObj, type) {
  try {
    const field = type === "offered" ? "skillsOffered" : "skillsWanted";
    await updateDoc(doc(db, "users", uid), { [field]: arrayRemove(skillObj) });
    return { success: true };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Get user's offered & wanted skills */
async function getUserSkills(uid) {
  try {
    const snap = await getDoc(doc(db, "users", uid));
    if (snap.exists()) {
      const d = snap.data();
      return { offered: d.skillsOffered || [], wanted: d.skillsWanted || [] };
    }
    return { offered: [], wanted: [] };
  } catch (e) { console.error("getUserSkills:", e); return { offered: [], wanted: [] }; }
}


// ============================================================
// 6.  MATCHING ALGORITHM  functions
// ============================================================

/**
 * Find potential peer-to-peer matches for the current user.
 * Logic: If I offer X & want Y, and another user offers Y & wants X → match.
 */
async function findMatches(currentUid) {
  try {
    const mySnap = await getDoc(doc(db, "users", currentUid));
    if (!mySnap.exists()) return [];

    const me        = mySnap.data();
    const myOffer   = (me.skillsOffered || []).map(s => s.name.toLowerCase());
    const myWant    = (me.skillsWanted  || []).map(s => s.name.toLowerCase());
    if (!myOffer.length || !myWant.length) return [];

    const allSnap   = await getDocs(collection(db, "users"));
    const results   = [];

    allSnap.forEach(d => {
      if (d.id === currentUid) return;                       // skip self
      const other       = d.data();
      const theirOffer  = (other.skillsOffered || []).map(s => s.name.toLowerCase());
      const theirWant   = (other.skillsWanted  || []).map(s => s.name.toLowerCase());

      // I teach them (my offered ∩ their wanted)
      const iTeach    = myOffer.filter(s => theirWant.includes(s));
      // They teach me (their offered ∩ my wanted)
      const theyTeach = theirOffer.filter(s => myWant.includes(s));

      if (iTeach.length > 0 && theyTeach.length > 0) {
        results.push({
          userId:         d.id,
          displayName:    other.displayName,
          email:          other.email,
          bio:            other.bio || "",
          averageRating:  other.averageRating || 0,
          iTeach,
          theyTeach,
          matchScore:     iTeach.length + theyTeach.length
        });
      }
    });

    results.sort((a, b) => b.matchScore - a.matchScore);
    return results;
  } catch (e) { console.error("findMatches:", e); return []; }
}

/** Send a match request (status = 'pending') */
async function createMatchRequest(fromUid, toUid, skillsExchange) {
  try {
    const matchId = [fromUid, toUid].sort().join("_");
    const existing = await getDoc(doc(db, "matches", matchId));
    if (existing.exists()) return { success: false, error: "Match already exists." };

    await setDoc(doc(db, "matches", matchId), {
      matchId,
      users:      [fromUid, toUid],
      initiator:  fromUid,
      receiver:   toUid,
      skillsExchange: {
        [fromUid]: skillsExchange.iTeach,
        [toUid]:   skillsExchange.theyTeach
      },
      status:    "pending",
      sessions:  [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return { success: true, matchId };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Accept or reject a match */
async function updateMatchStatus(matchId, status) {
  try {
    await updateDoc(doc(db, "matches", matchId), { status, updatedAt: serverTimestamp() });
    return { success: true };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Real-time listener for all matches involving a user */
function listenToMatches(uid, callback) {
  const q = query(collection(db, "matches"), where("users", "array-contains", uid));
  return onSnapshot(q, snap => {
    const arr = [];
    snap.forEach(d => arr.push(d.data()));
    callback(arr);
  });
}

/** Fetch a single match document */
async function getMatch(matchId) {
  try {
    const snap = await getDoc(doc(db, "matches", matchId));
    return snap.exists() ? snap.data() : null;
  } catch (e) { console.error("getMatch:", e); return null; }
}


// ============================================================
// 7.  CHAT  functions  (Firebase Realtime Database)
// ============================================================

/** Send a message in a match chat room */
function sendMessage(matchId, senderId, senderName, text) {
  const chatRef   = ref(rtdb, `chats/${matchId}`);
  const newMsgRef = push(chatRef);
  return rtdbSet(newMsgRef, {
    senderId,
    senderName,
    text,
    timestamp: Date.now()
  });
}

/** Listen for new messages (real-time, fires per new child) */
function listenToChat(matchId, callback) {
  const chatRef = ref(rtdb, `chats/${matchId}`);
  onChildAdded(chatRef, snap => callback(snap.val()));
  return chatRef;
}

/** Stop listening */
function stopListeningToChat(chatRef) { off(chatRef); }

/** Fetch all messages once */
function getAllMessages(matchId, callback) {
  const chatRef = ref(rtdb, `chats/${matchId}`);
  onValue(chatRef, snap => {
    const msgs = [];
    snap.forEach(c => msgs.push(c.val()));
    callback(msgs);
  }, { onlyOnce: true });
}


// ============================================================
// 8.  SESSION SCHEDULING  functions
// ============================================================

/** Schedule a learning session inside a match document */
async function scheduleSession(matchId, sessionData) {
  try {
    const session = {
      id:          Date.now().toString(),
      matchId,
      scheduledBy: sessionData.scheduledBy,
      dateTime:    sessionData.dateTime,
      duration:    sessionData.duration || 60,
      topic:       sessionData.topic    || "",
      notes:       sessionData.notes    || "",
      status:      "scheduled",
      createdAt:   new Date().toISOString()
    };
    await updateDoc(doc(db, "matches", matchId), {
      sessions:  arrayUnion(session),
      updatedAt: serverTimestamp()
    });
    return { success: true, session };
  } catch (e) { return { success: false, error: e.message }; }
}


// ============================================================
// 9.  RATING & FEEDBACK  functions
// ============================================================

/** Submit a rating for another user after a session */
async function submitRating(targetUid, fromUid, matchId, ratingData) {
  try {
    await addDoc(collection(db, "ratings"), {
      targetUid, fromUid, matchId,
      rating:   ratingData.rating,
      feedback: ratingData.feedback || "",
      createdAt: serverTimestamp()
    });
    // Recalculate average
    const rq   = query(collection(db, "ratings"), where("targetUid", "==", targetUid));
    const snap = await getDocs(rq);
    let total = 0, count = 0;
    snap.forEach(r => { total += r.data().rating; count++; });
    const avg = count ? Math.round((total / count) * 10) / 10 : 0;
    await updateDoc(doc(db, "users", targetUid), { averageRating: avg });
    return { success: true };
  } catch (e) { return { success: false, error: e.message }; }
}

/** Get all ratings for a user */
async function getUserRatings(uid) {
  try {
    const q    = query(collection(db, "ratings"), where("targetUid", "==", uid));
    const snap = await getDocs(q);
    const arr  = [];
    snap.forEach(d => arr.push(d.data()));
    return arr;
  } catch (e) { console.error("getUserRatings:", e); return []; }
}


// ============================================================
// 10.  SEARCH USERS BY SKILL  (bonus feature)
// ============================================================

/** Search all users who offer a given skill name */
async function searchUsersBySkill(skillName) {
  try {
    const snap = await getDocs(collection(db, "users"));
    const results = [];
    const term = skillName.toLowerCase();
    snap.forEach(d => {
      const u = d.data();
      const match = (u.skillsOffered || []).some(s => s.name.toLowerCase().includes(term));
      if (match) results.push(u);
    });
    return results;
  } catch (e) { console.error("searchUsersBySkill:", e); return []; }
}


// ============================================================
// 11.  DARK-MODE TOGGLE  (bonus feature)
// ============================================================

function initDarkMode() {
  const saved = localStorage.getItem("ss-dark-mode");
  if (saved === "true") document.body.classList.add("dark-mode");
}
function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
  localStorage.setItem("ss-dark-mode", document.body.classList.contains("dark-mode"));
}


// ============================================================
// 12.  Expose everything on window.SS for inline scripts
// ============================================================
window.SS = {
  // constants
  SKILL_CATEGORIES,
  // auth
  auth, db, rtdb,
  observeAuth, signUp, login, logoutUser,
  getUserProfile, updateUserProfile, getCurrentUser,
  // skills
  addSkill, removeSkill, getUserSkills,
  // matching
  findMatches, createMatchRequest, updateMatchStatus,
  listenToMatches, getMatch,
  // chat
  sendMessage, listenToChat, stopListeningToChat, getAllMessages,
  // sessions
  scheduleSession,
  // ratings
  submitRating, getUserRatings,
  // search
  searchUsersBySkill,
  // dark mode
  initDarkMode, toggleDarkMode
};

// Auto-init dark mode on load
initDarkMode();

console.log("🔁 SwapSkills firebase-app.js loaded ✅");
